// src/environments/environment.ts
export const environment = {
    production: false,
    //apiUrl: 'https://bnbx.pro/api', // Live API URL
    apiUrl: 'http://localhost:8080', // Local API URL
};