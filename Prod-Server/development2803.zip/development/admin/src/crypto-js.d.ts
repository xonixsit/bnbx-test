declare module 'crypto-js' {
    const content: any;
    export = content;
  }
  