import { Component } from '@angular/core';

@Component({
  selector: 'app-team-transfer',
  templateUrl: './team-transfer.component.html',
  styleUrls: ['./team-transfer.component.scss']
})
export class TeamTransferComponent {

}
