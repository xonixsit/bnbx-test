import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PageEvent } from '@angular/material/paginator';
import { ToastrService } from 'ngx-toastr';
import { AuthServicesService } from 'src/app/services/auth/auth-services.service';
import { WalletServiceService } from 'src/app/services/wallet/wallet-service.service';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.scss']
})

export class FundTransferComponent {
  // Existing properties
  fundTransferForm: FormGroup;
  token: any;
  showPassword = false;
  referralName: any = '';
  page = 1;
  sizePerPage = 10;
  transactionType = 'FUND-TRANSFER';
  transactions: any = [];
  totalTransactions: number = 0;
  loading = false;
  totalInternalTransferBalance: any;

  // New properties
  mainBalance: number = 0;

  constructor(
    private walletService: WalletServiceService,
    private authServices: AuthServicesService,
    private fb: FormBuilder,
    private toastr: ToastrService
  ) {
    this.fundTransferForm = this.fb.group({
      amount: [0, [Validators.required, Validators.min(1)]],
      password: ['', Validators.required],
      walletType: ['main', Validators.required],
      referralCode: [{ value: '', disabled: true }]
    });

    // Add listener to enable/disable referralCode based on walletType
    this.fundTransferForm.get('walletType')?.valueChanges.subscribe(value => {
      const referralControl = this.fundTransferForm.get('referralCode');
      if (value === 'trade') {
        referralControl?.enable();
        referralControl?.setValidators([Validators.required]);
      } else {
        referralControl?.disable();
        referralControl?.clearValidators();
      }
      referralControl?.updateValueAndValidity();
    });
  }

  ngOnInit(): void {
    this.token = localStorage.getItem('authToken');
    this.getUserData();
  }

  // Updated getUserData method
  getUserData() {
    this.authServices.toggleLoader(true);
    this.authServices.getProfile(this.token).subscribe({
      next: (response) => {
        this.mainBalance = response.data.BUSDBalance;
        this.totalInternalTransferBalance = response.data.TRADEBalance;
        this.authServices.toggleLoader(false);
      },
      error: (error) => {
        this.toastr.error('Failed to load profile information', 'Error');
        this.authServices.toggleLoader(false);
      }
    });
  }

  // Keep existing checkReferralCode method
  // checkReferralCode() { ... }

  // New method for wallet to wallet transfer
  transferBetweenWallets() {
    if (this.fundTransferForm.valid) {
      this.authServices.toggleLoader(true);
      const transferData = {
        amount: this.fundTransferForm.value.amount,
        password: this.fundTransferForm.value.password
      };
      
      this.walletService.transferBetweenWallets(transferData, this.token).subscribe({
        next: (response) => {
          this.toastr.success(response.message ? response.message : "Transaction Successfull", '', {
            toastClass: 'toast-custom toast-success',
            positionClass: 'toast-bottom-center',
            closeButton: false,
            timeOut: 3000,
            progressBar: true
          });
          this.getUserData();
          this.fundTransferForm.reset();
          this.authServices.toggleLoader(false);
        },
        error: (err) => {
          this.authServices.toggleLoader(false);
          const errorMessage = err.error?.message || 'Transfer failed';
          this.toastr.error(errorMessage, '', {
            toastClass: 'toast-custom toast-error',
            positionClass: 'toast-bottom-center',
            closeButton: false,
            timeOut: 3000,
            progressBar: true
          });
        }
      });
    }
  }
  fundTransfer() {
    if (this.fundTransferForm.valid) {
      this.authServices.toggleLoader(true);
      const depositFormData = {
        amount: this.fundTransferForm.value.amount,
        referralCode: this.fundTransferForm.value.referralCode,
        password: this.fundTransferForm.value.password
      };
      this.walletService.fundTransferData(depositFormData, this.token).subscribe({
        next: (response) => {
          this.toastr.success(response.message, 'Transaction Successful', {
            toastClass: 'toast-custom toast-success',
            positionClass: 'toast-bottom-center',
            closeButton: false,
            timeOut: 3000,
            progressBar: true
          });
          this.getUserData()
          this.fundTransferForm.reset()
          this.authServices.toggleLoader(false);
        },
        error: (err) => {
          this.authServices.toggleLoader(false);
          const errorMessage = err.error?.message || 'Error processing the transaction';
          this.toastr.error(errorMessage, '', {
            toastClass: 'toast-custom toast-error',
            positionClass: 'toast-bottom-center',
            closeButton: false,
            timeOut: 3000,
            progressBar: true
          });
        }
      });
    }
  }
  // Helper method to determine which transfer method to use
  handleTransfer() {
    switch(this.fundTransferForm.value.walletType) {
        case 'trade':
            this.fundTransfer();
            break;
        case 'main':
            this.transferBetweenWallets();
            break;
        case 'trade-to-main':
            this.transferToMainWallet();
            break;
    }
}

transferToMainWallet() {
    const data = {
        amount: this.fundTransferForm.value.amount,
        password: this.fundTransferForm.value.password
    };
    
    this.walletService.transferToMain(data, this.token).subscribe({
        next: (response) => {
          this.toastr.success(response.message ? response.message : "Trade to Main Successfull", '', {
            toastClass: 'toast-custom toast-success',
            positionClass: 'toast-bottom-center',
            closeButton: false,
            timeOut: 3000,
            progressBar: true
          });
            this.getUserData(); // Changed from getUserBalance to getUserData to match existing method
            this.fundTransferForm.reset();
        },
        error: (error) => {
            this.toastr.error(error.error.message);
        }
    });
}
}
