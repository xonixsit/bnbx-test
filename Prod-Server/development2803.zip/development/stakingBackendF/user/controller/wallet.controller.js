const config = require("../../config/config");
const Web3 = require("web3");
const axios = require("axios");
const web3 = new Web3(config.RPC_URL);
const bcrypt = require("bcrypt");
const UserModel = require("../../models/users.model");
const TransactionModel = require("../../models/transactions.model");
const { handleErrorResponse, CustomErrorHandler } = require("../../middleware/CustomErrorHandler");

module.exports.transactionList = async (request, response) => {
    try {
        const { user } = request.body;
        const { page, sizePerPage, transactionType, status, startDate, endDate } = request.query;

        const userData = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!userData) throw CustomErrorHandler.unAuthorized("Access Denied!");

        const options = {
            page: parseInt(page) || 1,
            limit: parseInt(sizePerPage) || 10,
            sort: { createdAt: -1 },
            populate: {
                path: "fromUser",
                select: "name referralCode email",
            },
        };

        const query = {
            user: userData._id,
            ...(transactionType && { transactionType }),
            ...(status && { status }),
        };

        if (startDate || endDate) {
            query.createdAt = {};
            if (startDate) {
                query.createdAt.$gte = new Date(startDate);
            }
            if (endDate) {
                query.createdAt.$lte = new Date(endDate);
            }
        };

        const transactionList = await TransactionModel.paginate(query, options);

        if (!transactionList) {
            throw CustomErrorHandler.notFound("Transaction Not Found!");
        };

        return response.json({
            status: true,
            message: "Transactions List.",
            data: transactionList,
        });
    } catch (e) {
        handleErrorResponse(e, response);
    }
};

module.exports.getSingleTransactions = async (request, response) => {
    try {
        const { user } = request.body;
        const { id } = request.params;

        const userData = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!userData) throw CustomErrorHandler.unAuthorized("Access Denied!");

        const singleTransaction = await TransactionModel.findOne({
            _id: id,
            user: userData._id,
            isDeleted: false
        });
        if (!singleTransaction) throw CustomErrorHandler.notFound('Not found!');

        return response.json({
            status: true,
            message: "Transaction Details.",
            data: singleTransaction,
        });
    } catch (e) {
        handleErrorResponse(e, response);
    }
};

module.exports.swapWallet = async (request, response) => {
    try {
        const { user, amount, password } = request.body;

        const userData = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        }).select("+trxPassword");;
        if (!userData) throw CustomErrorHandler.unAuthorized("Access Denied!");

        if (!userData.isTrxPassCreated) throw CustomErrorHandler.wrongCredentials("Please create Transaction Password!");

        const checkPassword = await bcrypt.compare(password, userData.trxPassword);
        if (!checkPassword) {
            throw CustomErrorHandler.wrongCredentials("Wrong Transaction Password!");
        }

        if(userData.BUSDBalance < amount){
            throw CustomErrorHandler.lowBalance("Low USDT Balance!");
        };

        //Debit
        await TransactionModel.create({
            user: userData._id,
            transactionType: "SWAP-BUSD-TO-TRADE",
            amount: -amount,
            balanceType: "BUSD",
            currentBalance: userData.BUSDBalance - amount,
            description: `${amount} USDT Converted to TRADE`
        });
        //Credit
        const insertTransaction = await TransactionModel.create({
            user: userData._id,
            transactionType: "SWAP-BUSD-TO-TRADE",
            amount: amount,
            balanceType: "TRADE",
            currentBalance: userData.BUSDBalance - amount,
            description: `${amount} USDT TRADE Received`
        });

        userData.BUSDBalance -= amount;
        userData.TRADEBalance += Number(amount);
        await userData.save();

        return response.json({
            status: true,
            message: `${amount} USDT Swaped to TRADE.`,
            data: insertTransaction,
        });
    } catch (e) {
        handleErrorResponse(e, response);
    }
};

module.exports.convertReward = async (request, response) => {
    try {
        const { user } = request.body;

        const userData = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!userData) throw CustomErrorHandler.unAuthorized("Access Denied!");

        const convertAmount = userData.totalRewardBalance - userData.totalUnlockRewardBalnce;
        if(convertAmount <= 0) throw CustomErrorHandler.wrongCredentials("Nothing to Convert!");

        const convertRewardData = await TransactionModel.create({
            user: user._id,
            transactionType: "CONVERT-REWARD",
            amount: convertAmount,
            currentBalance: userData.BUSDBalance + convertAmount,
            description: `Converted Reward amount ${convertAmount}`
        });

        userData.BUSDBalance += convertAmount;
        userData.totalUnlockRewardBalnce += convertAmount;
        await userData.save();

        return response.json({
            status: true,
            message: "Reward Converted.",
            data: convertRewardData,
        });
    } catch (e) {
        console.log("Error While Converting Reward", e);
        handleErrorResponse(e, response);
    }
};

module.exports.internalTransafer = async (request, response) => {
    try {
        const { user, referralCode, password, amount } = request.body;
        
        const userData = await UserModel.findOne({
            _id: user._id,
            isInternalTransferAllowed: true,
            isDeleted: false,
        }).select("+trxPassword");;
        if (!userData) throw CustomErrorHandler.unAuthorized("Access Denied!");
        
        if (!userData.trxPassword){
            throw CustomErrorHandler.alreadyExist("Transaction Password Not Created!");
        }; 

        const recepientUser = await UserModel.findOne({
            $or: [
                { referralCode: referralCode.toUpperCase() },
                { loginId: referralCode }
            ],
            isDeleted: false
        });
        if (!recepientUser) throw CustomErrorHandler.unAuthorized("Recepient Not Found! or Deleted!");

        if (userData.referralCode === recepientUser.referralCode) {
            throw CustomErrorHandler.wrongCredentials("Recepient Must be a Different User!");
        };

        if (userData.TRADEBalance < amount) {
            throw CustomErrorHandler.lowBalance("Low TRADE Balance!");
        };

        const checkPassword = await bcrypt.compare(password, userData.trxPassword);
        if (!checkPassword) throw CustomErrorHandler.wrongCredentials("Wrong Transaction Password!");

        const transferData = await TransactionModel.create({
            amount: -amount,
            user: userData._id,
            fromUser: recepientUser._id,
            transactionType: "FUND-TRANSFER",
            balanceType: "TRADE",
            currentBalance: userData.BUSDBalance,
            description: `${amount} USDT Send to user ${recepientUser.loginId}`
        });

        await TransactionModel.create({
            amount: amount,
            fromUser: userData._id,
            user: recepientUser._id,
            balanceType: "TRADE",
            transactionType: "FUND-TRANSFER",
            currentBalance: recepientUser.BUSDBalance ,
            description: `${amount} USDT received from user ${userData.loginId}`
        });

        userData.TRADEBalance -= amount;
        await userData.save();

        recepientUser.TRADEBalance += Number(amount);
        await recepientUser.save();

        return response.json({
            status: true,
            message: `${amount} USDT TRADE Balance Send.`,
            data: transferData,
        });
    } catch (e) {
        console.log("Error While Internal Transfer", e);
        handleErrorResponse(e, response);
    }
};

module.exports.transferToTrade = async (request, response) => {
    try {
        const { user, amount, password } = request.body;

        const userData = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        }).select("+trxPassword");
        console.log('user',userData);
        if (!userData) throw CustomErrorHandler.unAuthorized("Access Denied!");
        if (!userData.isTrxPassCreated) throw CustomErrorHandler.wrongCredentials("Please create Transaction Password!");

        const checkPassword = await bcrypt.compare(password, userData.trxPassword);
        if (!checkPassword) throw CustomErrorHandler.wrongCredentials("Wrong Transaction Password!");

        if (userData.BUSDBalance < amount) {
            throw CustomErrorHandler.lowBalance("Low USDT Balance!");
        }

        // Debit from main balance
        await TransactionModel.create({
            user: userData._id,
            transactionType: "MAIN-TO-TRADE",
            amount: -amount,
            balanceType: "BUSD",
            currentBalance: userData.BUSDBalance - amount,
            description: `${amount} USDT transferred to Trade Wallet`
        });

        // Credit to trade balance
        const transferData = await TransactionModel.create({
            user: userData._id,
            transactionType: "MAIN-TO-TRADE",
            amount: amount,
            balanceType: "TRADE",
            currentBalance: userData.TRADEBalance + amount,
            description: `${amount} USDT TRADE received from Main Wallet`
        });

        // Update user balances
        userData.BUSDBalance -= amount;
        userData.TRADEBalance += Number(amount);
        await userData.save();

        return response.json({
            status: true,
            message: `${amount} USDT transferred to Trade Wallet`,
            data: transferData,
        });
    } catch (e) {
        console.log("Error in transferToTrade:", e);
        handleErrorResponse(e, response);
    }
};

module.exports.tradeToMain = async (request, response) => {
    try {
        const { user, amount, password } = request.body;

        const userData = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        }).select("+trxPassword");

        if (!userData) throw CustomErrorHandler.unAuthorized("Access Denied!");
        if (!userData.isTrxPassCreated) throw CustomErrorHandler.wrongCredentials("Please create Transaction Password!");

        const checkPassword = await bcrypt.compare(password, userData.trxPassword);
        if (!checkPassword) throw CustomErrorHandler.wrongCredentials("Wrong Transaction Password!");

        if (userData.TRADEBalance < amount) {
            throw CustomErrorHandler.lowBalance("Low TRADE Balance!");
        }

        // Debit from trade balance
        await TransactionModel.create({
            user: userData._id,
            transactionType: "TRADE-TO-MAIN",
            amount: -amount,
            balanceType: "TRADE",
            currentBalance: userData.TRADEBalance - amount,
            description: `${amount} USDT transferred to Main Wallet`
        });

        // Credit to main balance
        const transferData = await TransactionModel.create({
            user: userData._id,
            transactionType: "TRADE-TO-MAIN",
            amount: amount,
            balanceType: "BUSD",
            currentBalance: userData.BUSDBalance + amount,
            description: `${amount} USDT received from Trade Wallet`
        });

        // Update user balances
        userData.TRADEBalance -= amount;
        userData.BUSDBalance += Number(amount);
        await userData.save();

        return response.json({
            status: true,
            message: `${amount} USDT transferred to Main Wallet`,
            data: transferData,
        });
    } catch (e) {
        console.log("Error in tradeToMain:", e);
        handleErrorResponse(e, response);
    }
};

module.exports.withdrawUsdt = async (request, response) => {
    try {
        const { amount, chain, address, password, user, source } = request.body;
        
        const userData = await UserModel.findOne({
            _id: user._id,
            isWithdrawAllowed: true,
            isDeleted: false,
        }).select("+trxPassword");

        // Check minimum deposit requirement
        const totalDeposits = await TransactionModel.aggregate([
            {
                $match: {
                    user: userData._id,
                    transactionType: "DEPOSIT",
                    status: "COMPLETED",
                    isDeleted: false
                }
            },
            {
                $group: {
                    _id: null,
                    total: { $sum: "$amount" }
                }
            }
        ]);

        const totalDepositAmount = totalDeposits.length > 0 ? totalDeposits[0].total : 0;
        if (totalDepositAmount < 100) {
            throw CustomErrorHandler.unAuthorized("Minimum deposit of $100 required to make withdrawals");
        }

        // Add withdrawal lock validation
        const activeDeposits = await TransactionModel.find({
            user: userData._id,
            transactionType: "DEPOSIT",
            status: "COMPLETED",
            isDeleted: false
        });

        let totalStakedAmount = 0;
        let isLocked = false;
        let latestLockEndDate = null;

        // Check lock status for each deposit
        activeDeposits.forEach(deposit => {
            totalStakedAmount += deposit.amount;
            
            if (deposit.planDetails && deposit.planDetails.lockPeriod) {
                const lockEndDate = new Date(deposit.createdAt);
                lockEndDate.setDate(lockEndDate.getDate() + deposit.planDetails.lockPeriod);
                
                if (lockEndDate > new Date()) {
                    isLocked = true;
                    if (!latestLockEndDate || lockEndDate > latestLockEndDate) {
                        latestLockEndDate = lockEndDate;
                    }
                }
            }
        });

        // Calculate withdrawable amount
        const withdrawableBalance = Math.max(0, userData.BUSDBalance - totalStakedAmount);

        if (isLocked && amount > withdrawableBalance) {
            throw CustomErrorHandler.unAuthorized(`Withdrawal amount exceeds unlocked balance. Maximum withdrawable amount: ${withdrawableBalance} USDT`);
        }

        // Rest of the existing withdrawal logic
        if (!userData) throw CustomErrorHandler.unAuthorized("Access Denied!, Create Transaction Password!");

        if (!userData.isTrxPassCreated) throw CustomErrorHandler.wrongCredentials("Please create Transaction Password!");

        if (amount < Number(config.MIN_WITHDRAW) || amount > Number(config.MAX_WITHDRAW)) {
            throw CustomErrorHandler.wrongCredentials("Minimum 5 USDT CAN Withdraw At A Day!");
        };

        // Rest of the withdrawal logic remains the same
        const checkPassword = await bcrypt.compare(password, userData.trxPassword);
        if (!checkPassword) {
            throw CustomErrorHandler.wrongCredentials("Wrong Transaction Password!");
        }

        if (amount < Number(config.MIN_WITHDRAW) || amount > Number(config.MAX_WITHDRAW)) {
            throw CustomErrorHandler.wrongCredentials("Minimum 5 USDT CAN Withdraw At A Day!");
        };

        const lastWithdrawal = await TransactionModel.findOne({
            user: user._id,
            transactionType: "WITHDRAW",
            status: "COMPLETED",
            isDeleted: false,
        }).sort({ createdAt: -1 });


        const twentyFourHoursAgo = new Date();
        twentyFourHoursAgo.setHours(twentyFourHoursAgo.getHours() - 24);

        // if (lastWithdrawal && lastWithdrawal.createdAt > twentyFourHoursAgo) {
        //     throw CustomErrorHandler.unAuthorized("You Are Allowed To Make One Withdrawal in Every 24 Hours!");
        // };


        if (userData.BUSDBalance < amount) {
            throw CustomErrorHandler.lowBalance("Low USDT Balance!");
        };

        // Use provided address or fallback to user's wallet address
        const withdrawalAddress = address || userData.walletAddress;
        if (!withdrawalAddress) {
            throw CustomErrorHandler.notFound("Withdrawal Address Not Found!");
        }
        // console.log("withdrawalAddress chain", chain);
        let transactionData;
        // In the withdrawUsdt function, modify the BEP20 section:
        if (chain === 'BEP20') {
            // console.log("Starting BEP20 withdrawal process");
            // const contract = new web3.eth.Contract(config.ABI, config.USDT_CONTRACT_ADDRESS);
            
            // const amountInWei = web3.utils.toWei((amount*95/100).toString(), 'ether');
            
            // Create pending transaction first
            transactionData = await TransactionModel.create({
                user: userData._id,
                amount: -amount,
                transactionType: "WITHDRAW",
                withdrawalSource: source,  // Add withdrawal source
                chain: chain,
                withdrawAddress: address,
                currentBalance: userData.BUSDBalance - amount,
                status: "PENDING",
                description: `${amount} USDT withdrawal from ${source} on ${chain}-${address}`,
                address: address
            });
        
            // Update user balance
            userData.BUSDBalance -= amount;
            userData.totalWithdrawalBalance += amount;
            await userData.save();
        
            return response.json({
                status: true,
                message: 'Withdrawal request submitted successfully. Pending approval.',
                data: transactionData,
            });
        }
         else if (chain === 'TRC20') {
            transactionData = await TransactionModel.create({
                user: userData._id,
                amount: -amount, 
                transactionType: "WITHDRAW",
                chain: chain,
                withdrawAddress: withdrawalAddress,
                currentBalance: userData.BUSDBalance - amount,
                status: "PENDING",
                description: `${amount} USDT withdrawal on ${chain}-${address}`
            });
        }

        userData.BUSDBalance -= amount;
        userData.totalWithdrawalBalance += amount;
        await userData.save();

        return response.json({
            status: true,
            message: chain === 'BEP20' ? `${amount} USDT Sent.` : 'Withdrawal request submitted successfully.',
            data: transactionData,
        });
    } catch (e) {
        console.log("Detailed Error in Withdraw:", {
            message: e.message,
            stack: e.stack,
            type: e.constructor.name
        });
        handleErrorResponse(e, response);
    }
};

module.exports.createTransactionPassword = async (request, response) => {
    try {
        const { user, password, cnfPassword } = request.body;

        const userData = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        }).select("+trxPassword");
        if (!userData) throw CustomErrorHandler.unAuthorized("Access Denied!");

        if (!userData.isWithdrawAllowed) {
            throw CustomErrorHandler.unAuthorized("Withdrawals are currently not allowed for your account!");
        }

        if (userData.trxPassword){
            throw CustomErrorHandler.alreadyExist("Already Created Transaction Password!");
        }; 

        if (password !== cnfPassword) {
            throw CustomErrorHandler.wrongCredentials("Confirm Password Not Match!");
        };

        const passwordSalt = await bcrypt.genSalt(Number(config.SALT_ROUND));
        const passwordHash = await bcrypt.hash(password, passwordSalt);

        userData.trxPassword = passwordHash;
        userData.isTrxPassCreated = true;
        await userData.save();

        return response.json({
            status: true,
            message: "Transaction Password Created.",
            data: userData,
        });
    } catch (e) {
        console.log("Error while Create Transaction password", e);
        handleErrorResponse(e, response);
    }
};

module.exports.changeTransactionPassword = async (request, response) => {
    try {
        const { user, prevPassword, newPassword, cnfPassword } = request.body;

        const userData = await UserModel.findOne({
            _id: user._id,
            isDeleted: false
        }).select("+trxPassword");
        if (!userData) throw CustomErrorHandler.unAuthorized("Access Denied!");

        const checkPassword = await bcrypt.compare(
            prevPassword,
            userData.trxPassword
        );
        if (!checkPassword) throw CustomErrorHandler.wrongCredentials("Wrong Previous Password!");

        if (newPassword !== cnfPassword) {
            throw CustomErrorHandler.wrongCredentials("Confirm Password Not Match!");
        };

        const passwordSalt = await bcrypt.genSalt(config.SALT_ROUND);
        const passwordHash = await bcrypt.hash(newPassword, passwordSalt);

        userData.trxPassword = passwordHash;
        await userData.save();

        return response.json({
            status: true,
            message: "Transaction Password Changed.",
            data: null,
        });
    } catch (e) {
        console.log("Error while Changing Transaction password", e);
        handleErrorResponse(e, response);
    }
};

module.exports.updateWalletAddress = async (request, response) => {
    try {
        const { user, address } = request.body;

        const userData = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });
        if (!userData) {
            throw CustomErrorHandler.unAuthorized("Access Denied!");
        };

        if (!web3.utils.isAddress(address)) {
            throw CustomErrorHandler.wrongCredentials("Wrong Address!");
        };

        const checkAddress = await UserModel.findOne({
            walletAddress: address,
        });
        if (checkAddress) throw CustomErrorHandler.alreadyExist("Exists Address!");

        userData.walletAddress = address;
        userData.isWalletAdded = true;
        await userData.save();

        return response.json({
            status: true,
            message: "Wallet address Added.",
            data: userData,
        });
    } catch (e) {
        console.log("Error while Updating Wallet Address", e);
        handleErrorResponse(e, response);
    }
};

module.exports.getWithdrawalLockStatus = async (request, response) => {
    try {
        const { user } = request.body;

        const userData = await UserModel.findOne({
            _id: user._id,
            isDeleted: false,
        });

        // Get regular deposits (non-staking)
        const deposits = await TransactionModel.find({
            user: userData._id,
            transactionType: "DEPOSIT",
            status: "COMPLETED",
            isDeleted: false
        }).sort({ createdAt: -1 });

        // Get bonded/staked amounts
        const bondedTransactions = await TransactionModel.find({
            user: userData._id,
            transactionType: "BOND-IN",
            status: "COMPLETED",
            isDeleted: false
        }).sort({ createdAt: -1 });

        // Get referral income
        const referralIncome = await TransactionModel.aggregate([
            {
                $match: {
                    user: userData._id,
                    transactionType: "REFER-INCOME",
                    status: "COMPLETED",
                    isDeleted: false
                }
            },
            {
                $group: {
                    _id: null,
                    total: { $sum: "$amount" }
                }
            }
        ]);

        // Get bonuses (signup and other bonuses)
        const bonuses = await TransactionModel.aggregate([
            {
                $match: {
                    user: userData._id,
                    transactionType: { $in: ["SIGNUP-BONUS"] },
                    status: "COMPLETED",
                    isDeleted: false
                }
            },
            {
                $group: {
                    _id: null,
                    total: { $sum: "$amount" }
                }
            }
        ]);

        // Get total withdrawn amount
        const withdrawals = await TransactionModel.aggregate([
            {
                $match: {
                    user: userData._id,
                    transactionType: "WITHDRAW",
                    status: "COMPLETED",
                    isDeleted: false
                }
            },
            {
                $group: {
                    _id: null,
                    total: { $sum: { $abs: "$amount" } }  // Use $abs to handle negative amounts
                }
            }
        ]);

        // Calculate totals
        const totalDeposits = deposits.reduce((sum, tx) => sum + tx.amount, 0);
        const totalBonded = bondedTransactions.reduce((sum, tx) => sum + tx.amount, 0);
        const totalReferralIncome = referralIncome.length > 0 ? referralIncome[0].total : 0;
        const totalBonuses = bonuses.length > 0 ? bonuses[0].total : 0;
        const totalWithdrawn = withdrawals.length > 0 ? withdrawals[0].total : 0;  // No need for Math.abs here

        // Process bonded transactions for lock status
        const activePlans = [];
        let latestLockEndDate = null;
        let totalLockedAmount = 0;

        bondedTransactions.forEach(bond => {
            if (bond.planDetails && bond.planDetails.lockPeriod) {
                const depositDate = new Date(bond.createdAt);
                const lockEndDate = new Date(depositDate);
                lockEndDate.setDate(lockEndDate.getDate() + bond.planDetails.lockPeriod);
                const isLocked = lockEndDate > new Date();

                if (isLocked) {
                    totalLockedAmount += bond.amount;
                }

                activePlans.push({
                    planName: bond.planDetails.planName || 'Standard Plan',
                    depositAmount: bond.amount,
                    depositDate: bond.createdAt,
                    lockPeriod: `${bond.planDetails.lockPeriod} days`,
                    dailyRate: bond.planDetails.dailyRate,
                    expiryDate: lockEndDate,
                    status: isLocked ? 'Locked' : 'Unlocked'
                });

                if (isLocked && (!latestLockEndDate || lockEndDate > latestLockEndDate)) {
                    latestLockEndDate = lockEndDate;
                }
            }
        });

        // Calculate withdrawable amount
        const withdrawableBalance = Math.max(0, userData.BUSDBalance - totalLockedAmount);

        return response.json({
            status: true,
            balanceBreakdown: {
                totalBalance: userData.BUSDBalance || 0,
                regularDeposits: totalDeposits,
                bondedAmount: totalBonded,
                referralIncome: totalReferralIncome,
                bonusAmount: totalBonuses,  // Added bonus amount
                lockedAmount: totalLockedAmount,
                withdrawableAmount: Number(withdrawableBalance.toFixed(2)),
                totalWithdrawn: totalWithdrawn,  // Added total withdrawn amount
            },
            lockStatus: {
                isLocked: latestLockEndDate ? latestLockEndDate > new Date() : false,
                lockedUntil: latestLockEndDate ? latestLockEndDate.toISOString() : null
            },
            activePlans: activePlans
        });
    } catch (error) {
        console.log("Error in getWithdrawalLockStatus:", error);
        handleErrorResponse(error, response);
    }
};